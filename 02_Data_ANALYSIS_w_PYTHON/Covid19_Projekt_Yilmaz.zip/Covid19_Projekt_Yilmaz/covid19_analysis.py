import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

sns.set_theme(style="whitegrid")
pd.set_option('display.max_columns', 1000)
pd.set_option('display.width', 4000)
pd.set_option('display.max_rows', None)

covid_who = pd.read_csv('https://covid19.who.int/WHO-COVID-19-global-data.csv')

col_list = list(covid_who.columns.values)
col_list = list(map(lambda x: x.strip(), col_list))
covid_who.rename(
    columns={' Date_reported': 'Date_reported',
             ' Country_code': 'Country_code',
             ' Country': 'Country',
             ' WHO_region': 'WHO_region',
             ' New_cases': 'New_cases',
             ' Cumulative_cases': 'Cumulative_cases',
             ' New_deaths': 'New_deaths',
             ' Cumulative_deaths': 'Cumulative_deaths'}, inplace=True)

# print(covid_who.shape)
"""- Shape : (73913, 8)"""
# print(covid_who.columns)
"""columns : ['Date_reported', 'Country_code', 'Country', 'WHO_region', 'New_cases',
           'Cumulative_cases', 'New_deaths', 'Cumulative_deaths']"""
# print(covid_who["WHO_region"].value_counts())
"""
- WHO African Region : AFRO
- WHO Region for the Americas : AMRO
- WHO Eastern Mediterranean Region : EMRO
- WHO European Region : EURO
- WHO South-East Asia Region : SEARO
- WHO Western Pacific Region : WPRO
- Others : Other
"""

# Top 20 Countries Total Confirmed Cases as of Today:
sum_df = covid_who.groupby(by='Country').sum()
sorted_df = sum_df.sort_values(by='New_cases', ascending=False, ignore_index=False)[["New_cases", "New_deaths"]].head(20)
sorted_df.reset_index(inplace=True)
sorted_df.rename(columns={"index": "Country", "New_cases": "total_cases", "New_deaths": "total_deaths"}, inplace=True)
# print(sorted_df.dtypes)
# print(sorted_df)

# Plotting Total Cases for Top 20 Countries:
plt.figure(figsize=(22, 12))
s_plot = sns.barplot(y="Country", x="total_cases", data=sorted_df)
for p in s_plot.patches:
    # print(p)
    s_plot.annotate((int(p.get_width())), (p.get_x() + p.get_width() + 100000, p.get_y() + 0.6), size=14)
plt.xlabel("Total Cases", size=14)
plt.ylabel("")
plt.title("COVID19 Total Cases as of Today - Top 20 Countries", size=18)
plt.xlim(right=11000000)
plt.yticks(size=14)
plt.savefig("Total Cases Top 20 Countries.jpeg")

# Plotting Daily New Cases by WHO Region:
region_df = covid_who.groupby(by=['WHO_region', 'Date_reported'], as_index=False).sum()
plt.figure(figsize=(25, 12))
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "EURO"], label="Europe", color="royalblue")
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "AMRO"], label="America", color="lightgrey")
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "SEARO"], label="Southeast Asia", color="g")
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "EMRO"], label="Eastern Mediterranean", color="orange")
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "AFRO"], label="Africa", color="r")
sns.barplot(x='Date_reported', y="New_cases", data=region_df[region_df['WHO_region'] == "WPRO"], label="Western Pacific", color="m")
plt.ylabel("Daily New Cases", size=20, labelpad=-1500)
plt.title("COVID19 Daily New Cases - WHO Regions", size=24)
plt.xticks(rotation=45, ticks=list(range(1, 315, 15)), size=16)
plt.tick_params(axis='y', labelright='on')
plt.yticks(size=18)
sns.despine(left=True, right=False)
plt.legend(loc="center left", prop={'size': 22})
plt.savefig("Daily New Cases by WHO Region.jpeg")
