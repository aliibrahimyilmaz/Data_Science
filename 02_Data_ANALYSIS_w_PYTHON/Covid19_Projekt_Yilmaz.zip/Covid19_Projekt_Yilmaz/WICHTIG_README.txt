1. Dieses Projekt besteht aus zwei teilen. Erste Teil handelt von Covid19 Analyse und zweite Teil ist für Covid19-Mapping.

2. Erste Teil besteht aus;
	- ein Python-Datei ("covid19_analysis.py") 
	- zwei Grafiken als Ergebnisse von dem Python-Program ("Total Cases Top 20 Countries.jpeg", "Daily New Cases by WHO 	  Region.jpeg")

   Nach jeder Ausführung der Datei werden zwei aktuelle Grafiken erzeugt und in die Ordner speichert. Dieses Program ruft aktuel Covid19 csv datei aus WHO(World Health Organization) URL auf und es umwandelt CSV-Datei in Pandas DataFrame. Nach der Bereinigung, Sortierung und Slicing werden zwei Grafiken erzeugt. Alle andere nötige Kommentaren wurde in der Programmen geschrieben.

3. Zweite Teil besteht aus;
	- drei Python-Datei ("Covid19_viz_confirmed.py", "Covid19_viz_deaths.py", "Covid19_viz_recovered.py")
	- drei bunte Welt Karten mit Zeit Gliederung ("Covid19_Confirmed_Cases.html", "Covid19_Total_Deaths.html", 	  "Covid19_Total_Recovery.html")
	- ein JSON Datei ("country_dict.json")
	- ein GEOJSON Datei ("Longitude_Graticules_and_World_Countries_Boundaries.geojson")

   Nach jeder Ausführung eines Programms wird eine aktuelle Grafik erzeugt und in die Ordner als "html" Datei speichert. Jede Python-Datei funktuniert unabhängig und außer CSV raw data sind alle drei Programm mit kleinen Unterschiede fast ähnlich erstellt. Diese Programmen rufen aktuel Covid19 csv datei aus Johns Hopkins University Github Konto auf und es umwandelt CSV-Datei in Pandas DataFrame. Nach der Bereinigung, Sortierung, Grupierung und Verbindung mit GEOJSON Datei in der Ordner wird eine bunte Welt-Karte mit Zeitgliederung erstellt.

4. In diesem Projekt wurden viele Modulen und Bibliotheken gelernt, gearbeitet und verwendet. Eine Liste davon ist hier erstellt:
	- pandas
	- numpy
	- pprint
	- branca
	- folium
	- matplotlib
	- seaborn
	- geopandas
	- json

5. Dieses Projekt kann auch weiter entwicklt werden und detalisierte Analyse durchgeführt werden. Vielen Dank!

Ali Yilmaz, 13/11/2020-Kassel        