import branca.colormap as cm  # dealing with color maps
import folium  # to visualize Python data on an interactive Leaflet map
import geopandas as gpd  # to make working with geospatial data -in Python easier
import numpy as np  # for scientific computing
import pandas as pd  # to use data analysis and manipulation tool
import matplotlib.pyplot as plt
import json
from folium.plugins import TimeSliderChoropleth
from pprint import pprint
import seaborn as sns

sns.set_theme(style="whitegrid")
pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 4000)
pd.set_option('display.max_rows', None)
# pd.set_option('display.max_colwidth', None)

# countries = gpd.read_file('Longitude_Graticules_and_World_Countries_Boundaries.geojson')

covid_who = pd.read_csv('https://covid19.who.int/WHO-COVID-19-global-data.csv')
col_list = list(covid_who.columns.values)
col_list = list(map(lambda x: x.strip(), col_list))
covid_who.rename(
    columns={' Date_reported': 'Date_reported',
             ' Country_code': 'Country_code',
             ' Country': 'Country',
             ' WHO_region': 'WHO_region',
             ' New_cases': 'New_cases',
             ' Cumulative_cases': 'Cumulative_cases',
             ' New_deaths': 'New_deaths',
             ' Cumulative_deaths': 'Cumulative_deaths'}, inplace=True)
print(covid_who[covid_who["Country"] == "Turkey"])
""" covid_who = covid_who[col_list]
# print(covid_who.columns.values)
# print(countries.head())
# print(countries[countries["CNTRY_NAME"] == "Aruba"])
countries.rename(columns={"CNTRY_NAME": "Country"}, inplace=True)

joined_df = covid_who.merge(countries, on="Country")
#print(joined_df)
joined_df.to_csv("joined_covid.csv", index=False)"""

cases_list = list(covid_who[covid_who["Country"] == "Turkey"]["New_cases"])
date_list = list(covid_who[covid_who["Country"] == "Turkey"]["Date_reported"])
"""print(cases_list)
sum1 = sum(cases_list[-7:])
print(cases_list[-7:])
sum2 = sum(cases_list[-14:-7])
print(cases_list[-14:-7])
print(sum1, sum2, sum1/sum2)"""
r_list = []
vor = sum(cases_list[(- 14):(- 7)])
nach = sum(cases_list[- 7:])
r_value = nach / vor
r_list.append(r_value)
for i in range(1, len(cases_list)):
    vor = sum(cases_list[(-i-14):(-i-7)])
    nach = sum(cases_list[-i-7:-i])
    try:
        r_value = nach/vor
        r_list.append(r_value)
    except ZeroDivisionError:
        r_value = 0
        r_list.append(r_value)
print(len(r_list), r_list[::-1])
print(len(date_list), date_list)
print(date_list[48], date_list[0])
print(cases_list[-7:])

x = date_list
y = r_list[::-1]
plt.figure(figsize=(12, 6))
sns.barplot(x=x[104:], y=y[104:], data=None)  # seit 01/04/2020 R value(7 Tage)
sns.lineplot(x=x[104:], y=y[104:])
plt.hlines(y=1, xmin="2020-04-16", xmax="2020-11-14", colors='r', linestyles='solid', label='')
plt.xticks(rotation=45, ticks=list(range(0, 213, 12)), size=12)
plt.xlim(left=0, right=213)
plt.ylabel("R-Value", size=14)
plt.title("COVID19 R-Value in der Türkei", size=18)
plt.tick_params(axis='y', labelright='on')
plt.show()
