import branca.colormap as cm  # dealing with color maps
import folium  # to visualize Python data on an interactive Leaflet map
import geopandas as gpd  # to make working with geospatial data -in Python easier
import numpy as np  # for scientific computing
import pandas as pd  # to use data analysis and manipulation tool
import matplotlib.pyplot as plt
import json
from folium.plugins import TimeSliderChoropleth
from pprint import pprint

pd.set_option('display.max_columns', 100)
pd.set_option('display.width', 4000)
pd.set_option('display.max_rows', None)
# pd.set_option('display.max_colwidth', None)

countries = gpd.read_file('Longitude_Graticules_and_World_Countries_Boundaries.geojson')
# print(type(countries))

covid_confirmed = pd.read_csv('https://raw.githubusercontent.com/CSSEGISandData/COVID-19/'
                              'master/csse_covid_19_data/csse_covid_19_time_series/'
                              'time_series_covid19_confirmed_global.csv')

# make sure that the country names match between the data and the geodata:
# fill NaN values with string covid_data:
covid_confirmed["Province/State"] = covid_confirmed["Province/State"].fillna("")

# concatenate two columns: new column --> Region
covid_confirmed["Region"] = covid_confirmed["Province/State"] + " " + covid_confirmed["Country/Region"]
covid_confirmed["Region"] = covid_confirmed["Region"].str.strip()

# rearrange the columns in covid_data
cols = list(covid_confirmed.columns.values)
cols = cols[-1:] + cols[:-1]
# print(cols)
covid_confirmed = covid_confirmed[cols]
# print(covid_confirmed)

# filling the Province/State with the name of countries in order to generate unique column:
for index in range(len(covid_confirmed)):
    if covid_confirmed["Province/State"][index] == "":
        covid_confirmed.at[index, "Province/State"] = covid_confirmed["Country/Region"][index]
        # print(covid_confirmed["Province/State"][index])
# print(covid_confirmed)

# countries_data: match with the covid data:
# print(countries.columns.values)
# print(countries["CNTRY_NAME"])

# as a result of match, country_dict.json is manually produced, there are different names for
# same countries. it would be problem for merging two dataframes
match_region = []
non_match = []
for sub_element in list(countries["CNTRY_NAME"]):
    for element in list(covid_confirmed["Region"]):
        if sub_element in element and sub_element not in match_region:
            match_region.append(sub_element)
            break
    if sub_element not in match_region:
        non_match.append(sub_element)

# print(len(match_region), match_region)
# print(len(non_match), non_match)
# print(list(covid_confirmed["Province/State"]))

# adding new column to the countries dataframe with the new names from covid_data:
with open("country_dict.json", "r", encoding="utf-8") as file:
    result_str = file.read()
    result_dict = json.loads(result_str)  # country naming dictionary
    # print(type(result_dict), result_dict)

country_list = []
for sub_element in list(countries["CNTRY_NAME"]):
    count = 0
    for element in list(covid_confirmed["Province/State"]):
        try:
            if sub_element in element:
                country_list.append(element)
                count = 1
                break
        except KeyError as e:
            print(e.__doc__)
            continue
    if count == 0:
        try:
            country_list.append(result_dict[sub_element])
        except:
            country_list.append(sub_element)

# print(len(country_list), country_list)
# print(countries["CNTRY_NAME"])
countries["Province/State"] = country_list

# print(countries)
# rearrange the columns in countries df:
cols = list(countries.columns.values)
cols = cols[0:1] + cols[-1:] + cols[1:-1]
# print(cols)
countries = countries[cols]

# Canada und China were divided into regions. They had to be combined into one country each:
group_confirmed = covid_confirmed.groupby(["Country/Region"], as_index=False).sum()
canada_china_df = group_confirmed[group_confirmed["Country/Region"].isin(["Canada", "China"])]
canada_china_df.rename(columns={"Country/Region": "Province/State"}, inplace=True)
# print(canada_china_df)

# canada, china dataframe was added to covid dataframe:
concat_df = covid_confirmed.append(canada_china_df, ignore_index=True)
# print(concat_df)

# Zaire is the name of Congo(Kinshasa), it has to be changed.
concat_df.loc[concat_df["Province/State"] == 'Congo (Kinshasa)', "Province/State"] = 'Zaire'
# print(concat_df)

# MERGING two big dataframes: covid + countries:
joined_df = concat_df.merge(countries, on="Province/State")
# joined_df = joined_df.sort_values(["Province/State"])
print(joined_df)

# rearrange the columns in joined_df:
cols = list(joined_df.columns.values)
cols = cols[0:3] + cols[-2:] + cols[3:-2]
# print(cols)
joined_df = joined_df[cols]

# dropping objectID, it is not used:
joined_df.drop("OBJECTID", axis=1, inplace=True)
# print(joined_df)

# Style Dict for countries: important for mapping. every single time will be represented
# according to countries cases value and color opacity: it will be used later.
# {key1: countryID,.....
#   {key2: date,......
#        {values: color, opacity}}}
country_list = joined_df["Province/State"].tolist()
# print(len(country_list))
country_idx = range(len(country_list))
# print(country_idx)
style_dict = {}

####################################################################################
# for a single country, for example "Vietnam": a time, a color value, and opacity dict was tried:
"""result_df = (np.log10(joined_df[joined_df["Province/State"] == "Vietnam"].iloc[:, 7:])).transpose()
result_df.reset_index(level=0, inplace=True)
column_list = result_df.columns.values
result_df.rename(columns={column_list[0]: "date", column_list[1]: "confirmed"}, inplace=True)
result_df[np.isneginf(result_df["confirmed"])] = 0
#print(result_df)
max_colour = max(result_df["confirmed"])
#print(max_colour)
min_colour = min(result_df["confirmed"])
#print(min_colour)
cmap = cm.linear.YlOrRd_09.scale(min_colour, max_colour)  # modul branca for colored map
result_df['colour'] = result_df["confirmed"].map(cmap)
result_df['date_sec'] = pd.to_datetime(result_df['date']).astype('int64') / 10**9
print(result_df)"""
######################################################################################
# style dictionary for every single country:
counter = 0
for i in country_idx:
    counter += 1
    country = country_list[i]
    result_df = (np.log10(joined_df[joined_df["Province/State"] == country].iloc[:, 7:])).transpose()
    result_df.reset_index(level=0, inplace=True)
    column_list = result_df.columns.values
    result_df.rename(columns={column_list[0]: "date", column_list[1]: "confirmed"}, inplace=True)
    result_df[np.isneginf(result_df["confirmed"])] = 0
    cmap = cm.linear.Blues_09.scale(0, 7.0)  # modul branca for colored map
    result_df['colour'] = result_df["confirmed"].map(cmap)  # cmap values added
    result_df['date_sec'] = pd.to_datetime(result_df['date']).astype('int64') / 10**9
    result_df['date_sec'] = result_df['date_sec'].astype(int).astype(str)
    inner_dict = {}
    for _, r in result_df.iterrows():
        inner_dict[r['date_sec']] = {'color': r['colour'], 'opacity': 0.7}
    style_dict[str(i)] = inner_dict

# colored map scale is defined according to logaritmic scale, because we have very small and very big values
cmap = cm.linear.Blues_09.scale(0, 7)  # modul branca for colored map
# print(joined_df)

# features of countries:
countries_df = joined_df[['geometry']]
countries_gdf = gpd.GeoDataFrame(countries_df)  # geo dataframe is hier defined.
# print(countries_gdf)

# to create our map:
slider_map = folium.Map(min_zoom=2, max_bounds=True, tiles='cartodbpositron')

# slider was created:
_ = TimeSliderChoropleth(data=countries_gdf.to_json(), styledict=style_dict).add_to(slider_map)

# color scale was added to the map:
_ = cmap.add_to(slider_map)

# scale map legend was added to the map:
cmap.caption = "Log of number of CONFIRMED CASES"

# map is saved to the directory as html file:
slider_map.save(outfile='Covid19_Confirmed_Cases.html')

